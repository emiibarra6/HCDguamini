// Form Layouts JavaScripts

(function ($) {
	'use strict';
  
	$("#form-validation").validate();
})(jQuery);
